import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page118',
  templateUrl: 'page118.html'
})
export class Page118Page {

  constructor(public navCtrl: NavController) {
  }
  
}
