import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page147',
  templateUrl: 'page147.html'
})
export class Page147Page {

  constructor(public navCtrl: NavController) {
  }
  
}
