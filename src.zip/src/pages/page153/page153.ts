import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page153',
  templateUrl: 'page153.html'
})
export class Page153Page {

  constructor(public navCtrl: NavController) {
  }
  
}
