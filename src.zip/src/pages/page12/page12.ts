import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Page143Page } from '../page143/page143';
import { Page145Page } from '../page145/page145';
import { Page146Page } from '../page146/page146';
import { Page147Page } from '../page147/page147';
import { Page148Page } from '../page148/page148';
import { Page149Page } from '../page149/page149';
import { Page150Page } from '../page150/page150';
import { Page151Page } from '../page151/page151';
import { Page152Page } from '../page152/page152';
import { Page153Page } from '../page153/page153';
import { Page154Page } from '../page154/page154';
import { Page155Page } from '../page155/page155';
import { Page156Page } from '../page156/page156';
import { Page157Page } from '../page157/page157';
import { Page158Page } from '../page158/page158';
import { Page159Page } from '../page159/page159';
import { Page109Page } from '../page109/page109';
import { Page144Page } from '../page144/page144';
import { Page170Page } from '../page170/page170';
import { Page166Page } from '../page166/page166';
import { Page167Page } from '../page167/page167';
import { Page168Page } from '../page168/page168';
import { Page169Page } from '../page169/page169';

@Component({
  selector: 'page-page12',
  templateUrl: 'page12.html'
})
export class Page12Page {

  constructor(public navCtrl: NavController) {
  }
  goToPage143(params){
    if (!params) params = {};
    this.navCtrl.push(Page143Page);
  }goToPage145(params){
    if (!params) params = {};
    this.navCtrl.push(Page145Page);
  }goToPage146(params){
    if (!params) params = {};
    this.navCtrl.push(Page146Page);
  }goToPage147(params){
    if (!params) params = {};
    this.navCtrl.push(Page147Page);
  }goToPage148(params){
    if (!params) params = {};
    this.navCtrl.push(Page148Page);
  }goToPage149(params){
    if (!params) params = {};
    this.navCtrl.push(Page149Page);
  }goToPage150(params){
    if (!params) params = {};
    this.navCtrl.push(Page150Page);
  }goToPage151(params){
    if (!params) params = {};
    this.navCtrl.push(Page151Page);
  }goToPage152(params){
    if (!params) params = {};
    this.navCtrl.push(Page152Page);
  }goToPage153(params){
    if (!params) params = {};
    this.navCtrl.push(Page153Page);
  }goToPage154(params){
    if (!params) params = {};
    this.navCtrl.push(Page154Page);
  }goToPage155(params){
    if (!params) params = {};
    this.navCtrl.push(Page155Page);
  }goToPage156(params){
    if (!params) params = {};
    this.navCtrl.push(Page156Page);
  }goToPage157(params){
    if (!params) params = {};
    this.navCtrl.push(Page157Page);
  }goToPage158(params){
    if (!params) params = {};
    this.navCtrl.push(Page158Page);
  }goToPage159(params){
    if (!params) params = {};
    this.navCtrl.push(Page159Page);
  }goToPage109(params){
    if (!params) params = {};
    this.navCtrl.push(Page109Page);
  }goToPage144(params){
    if (!params) params = {};
    this.navCtrl.push(Page144Page);
  }goToPage170(params){
    if (!params) params = {};
    this.navCtrl.push(Page170Page);
  }goToPage166(params){
    if (!params) params = {};
    this.navCtrl.push(Page166Page);
  }goToPage167(params){
    if (!params) params = {};
    this.navCtrl.push(Page167Page);
  }goToPage168(params){
    if (!params) params = {};
    this.navCtrl.push(Page168Page);
  }goToPage169(params){
    if (!params) params = {};
    this.navCtrl.push(Page169Page);
  }
}
