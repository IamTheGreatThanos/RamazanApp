import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page33',
  templateUrl: 'page33.html'
})
export class Page33Page {

  constructor(public navCtrl: NavController) {
  }
  
}
