import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page133',
  templateUrl: 'page133.html'
})
export class Page133Page {

  constructor(public navCtrl: NavController) {
  }
  
}
