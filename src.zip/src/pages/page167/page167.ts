import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page167',
  templateUrl: 'page167.html'
})
export class Page167Page {

  constructor(public navCtrl: NavController) {
  }
  
}
