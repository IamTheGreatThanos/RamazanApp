import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page142',
  templateUrl: 'page142.html'
})
export class Page142Page {

  constructor(public navCtrl: NavController) {
  }
  
}
