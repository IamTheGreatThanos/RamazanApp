import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page148',
  templateUrl: 'page148.html'
})
export class Page148Page {

  constructor(public navCtrl: NavController) {
  }
  
}
