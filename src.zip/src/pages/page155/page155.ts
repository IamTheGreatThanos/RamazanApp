import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Page117Page } from '../page117/page117';
import { Page118Page } from '../page118/page118';
import { Page119Page } from '../page119/page119';
import { Page120Page } from '../page120/page120';
import { Page121Page } from '../page121/page121';
import { Page122Page } from '../page122/page122';
import { Page123Page } from '../page123/page123';
import { Page124Page } from '../page124/page124';
import { Page125Page } from '../page125/page125';
import { Page126Page } from '../page126/page126';
import { Page127Page } from '../page127/page127';
import { Page128Page } from '../page128/page128';
import { Page129Page } from '../page129/page129';
import { Page130Page } from '../page130/page130';


@Component({
  selector: 'page-page155',
  templateUrl: 'page155.html'
})
export class Page155Page {

  constructor(public navCtrl: NavController) {
  }
  goToPage117(params){
    if (!params) params = {};
    this.navCtrl.push(Page117Page);
  }
  goToPage118(params){
    if (!params) params = {};
    this.navCtrl.push(Page118Page);
  }
  goToPage119(params){
    if (!params) params = {};
    this.navCtrl.push(Page119Page);
  }
  goToPage120(params){
    if (!params) params = {};
    this.navCtrl.push(Page120Page);
  }
  goToPage121(params){
    if (!params) params = {};
    this.navCtrl.push(Page121Page);
  }
  goToPage122(params){
    if (!params) params = {};
    this.navCtrl.push(Page122Page);
  }
  goToPage123(params){
    if (!params) params = {};
    this.navCtrl.push(Page123Page);
  }
  goToPage124(params){
    if (!params) params = {};
    this.navCtrl.push(Page124Page);
  }
  goToPage125(params){
    if (!params) params = {};
    this.navCtrl.push(Page125Page);
  }
  goToPage126(params){
    if (!params) params = {};
    this.navCtrl.push(Page126Page);
  }
  goToPage127(params){
    if (!params) params = {};
    this.navCtrl.push(Page127Page);
  }
  goToPage128(params){
    if (!params) params = {};
    this.navCtrl.push(Page128Page);
  }
  goToPage129(params){
    if (!params) params = {};
    this.navCtrl.push(Page129Page);
  }
  goToPage130(params){
    if (!params) params = {};
    this.navCtrl.push(Page130Page);
  }
}
