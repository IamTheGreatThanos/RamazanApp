import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page41',
  templateUrl: 'page41.html'
})
export class Page41Page {

  constructor(public navCtrl: NavController) {
  }
  
}
