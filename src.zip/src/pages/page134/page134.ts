import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page134',
  templateUrl: 'page134.html'
})
export class Page134Page {

  constructor(public navCtrl: NavController) {
  }
  
}
