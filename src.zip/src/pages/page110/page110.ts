import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page110',
  templateUrl: 'page110.html'
})
export class Page110Page {

  constructor(public navCtrl: NavController) {
  }
  
}
