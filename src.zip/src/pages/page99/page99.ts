import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page99',
  templateUrl: 'page99.html'
})
export class Page99Page {

  constructor(public navCtrl: NavController) {
  }
  
}
