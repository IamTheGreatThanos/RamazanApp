import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page132',
  templateUrl: 'page132.html'
})
export class Page132Page {

  constructor(public navCtrl: NavController) {
  }
  
}
