import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page29',
  templateUrl: 'page29.html'
})
export class Page29Page {

  constructor(public navCtrl: NavController) {
  }
  
}
