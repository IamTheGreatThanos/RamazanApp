import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page70',
  templateUrl: 'page70.html'
})
export class Page70Page {

  constructor(public navCtrl: NavController) {
  }
  
}
