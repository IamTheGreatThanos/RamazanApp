import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page112',
  templateUrl: 'page112.html'
})
export class Page112Page {

  constructor(public navCtrl: NavController) {
  }
  
}
