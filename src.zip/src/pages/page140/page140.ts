import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page140',
  templateUrl: 'page140.html'
})
export class Page140Page {

  constructor(public navCtrl: NavController) {
  }
  
}
