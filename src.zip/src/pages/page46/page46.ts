import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page46',
  templateUrl: 'page46.html'
})
export class Page46Page {

  constructor(public navCtrl: NavController) {
  }
  
}
