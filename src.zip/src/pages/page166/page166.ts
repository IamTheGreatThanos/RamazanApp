import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page166',
  templateUrl: 'page166.html'
})
export class Page166Page {

  constructor(public navCtrl: NavController) {
  }
  
}
