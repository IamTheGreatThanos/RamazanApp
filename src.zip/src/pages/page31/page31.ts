import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page31',
  templateUrl: 'page31.html'
})
export class Page31Page {

  constructor(public navCtrl: NavController) {
  }
  
}
