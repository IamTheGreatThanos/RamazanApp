import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page61',
  templateUrl: 'page61.html'
})
export class Page61Page {

  constructor(public navCtrl: NavController) {
  }
  
}
