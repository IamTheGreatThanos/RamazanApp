import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page54',
  templateUrl: 'page54.html'
})
export class Page54Page {

  constructor(public navCtrl: NavController) {
  }
  
}
