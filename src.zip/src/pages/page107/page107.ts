import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page107',
  templateUrl: 'page107.html'
})
export class Page107Page {

  constructor(public navCtrl: NavController) {
  }
  
}
