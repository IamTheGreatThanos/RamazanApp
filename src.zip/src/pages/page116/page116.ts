import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page116',
  templateUrl: 'page116.html'
})
export class Page116Page {

  constructor(public navCtrl: NavController) {
  }
  
}
