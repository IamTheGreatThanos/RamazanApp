import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page149',
  templateUrl: 'page149.html'
})
export class Page149Page {

  constructor(public navCtrl: NavController) {
  }
  
}
