import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page58',
  templateUrl: 'page58.html'
})
export class Page58Page {

  constructor(public navCtrl: NavController) {
  }
  
}
