import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page45',
  templateUrl: 'page45.html'
})
export class Page45Page {

  constructor(public navCtrl: NavController) {
  }
  
}
