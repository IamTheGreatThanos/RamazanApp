import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page66',
  templateUrl: 'page66.html'
})
export class Page66Page {

  constructor(public navCtrl: NavController) {
  }
  
}
