import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page135',
  templateUrl: 'page135.html'
})
export class Page135Page {

  constructor(public navCtrl: NavController) {
  }
  
}
