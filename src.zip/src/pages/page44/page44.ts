import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page44',
  templateUrl: 'page44.html'
})
export class Page44Page {

  constructor(public navCtrl: NavController) {
  }
  
}
