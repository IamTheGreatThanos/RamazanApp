import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Page83Page } from '../page83/page83';
import { Page101Page } from '../page101/page101';
import { Page104Page } from '../page104/page104';
import { Page135Page } from '../page135/page135';
import { Page106Page } from '../page106/page106';
import { Page107Page } from '../page107/page107';
import { Page108Page } from '../page108/page108';
import { Page110Page } from '../page110/page110';
import { Page111Page } from '../page111/page111';
import { Page112Page } from '../page112/page112';
import { Page113Page } from '../page113/page113';
import { Page114Page } from '../page114/page114';
import { Page115Page } from '../page115/page115';
import { Page116Page } from '../page116/page116';
import { Page117Page } from '../page117/page117';
import { Page118Page } from '../page118/page118';
import { Page119Page } from '../page119/page119';
import { Page120Page } from '../page120/page120';
import { Page121Page } from '../page121/page121';
import { Page122Page } from '../page122/page122';
import { Page123Page } from '../page123/page123';
import { Page124Page } from '../page124/page124';
import { Page125Page } from '../page125/page125';
import { Page126Page } from '../page126/page126';
import { Page127Page } from '../page127/page127';
import { Page128Page } from '../page128/page128';
import { Page129Page } from '../page129/page129';
import { Page130Page } from '../page130/page130';
import { Page131Page } from '../page131/page131';
import { Page132Page } from '../page132/page132';
import { Page133Page } from '../page133/page133';
import { Page134Page } from '../page134/page134';
import { Page136Page } from '../page136/page136';
import { Page137Page } from '../page137/page137';
import { Page138Page } from '../page138/page138';
import { Page140Page } from '../page140/page140';
import { Page139Page } from '../page139/page139';
import { Page160Page } from '../page160/page160';
import { Page161Page } from '../page161/page161';
import { Page162Page } from '../page162/page162';
import { Page163Page } from '../page163/page163';
import { Page164Page } from '../page164/page164';
import { Page165Page } from '../page165/page165';

@Component({
  selector: 'page-page3',
  templateUrl: 'page3.html'
})
export class Page3Page {

  constructor(public navCtrl: NavController) {
  }
  goToPage83(params){
    if (!params) params = {};
    this.navCtrl.push(Page83Page);
  }goToPage101(params){
    if (!params) params = {};
    this.navCtrl.push(Page101Page);
  }goToPage104(params){
    if (!params) params = {};
    this.navCtrl.push(Page104Page);
  }goToPage135(params){
    if (!params) params = {};
    this.navCtrl.push(Page135Page);
  }goToPage106(params){
    if (!params) params = {};
    this.navCtrl.push(Page106Page);
  }goToPage107(params){
    if (!params) params = {};
    this.navCtrl.push(Page107Page);
  }goToPage108(params){
    if (!params) params = {};
    this.navCtrl.push(Page108Page);
  }goToPage110(params){
    if (!params) params = {};
    this.navCtrl.push(Page110Page);
  }goToPage111(params){
    if (!params) params = {};
    this.navCtrl.push(Page111Page);
  }goToPage112(params){
    if (!params) params = {};
    this.navCtrl.push(Page112Page);
  }goToPage113(params){
    if (!params) params = {};
    this.navCtrl.push(Page113Page);
  }goToPage114(params){
    if (!params) params = {};
    this.navCtrl.push(Page114Page);
  }goToPage115(params){
    if (!params) params = {};
    this.navCtrl.push(Page115Page);
  }goToPage116(params){
    if (!params) params = {};
    this.navCtrl.push(Page116Page);
  }goToPage117(params){
    if (!params) params = {};
    this.navCtrl.push(Page117Page);
  }goToPage118(params){
    if (!params) params = {};
    this.navCtrl.push(Page118Page);
  }goToPage119(params){
    if (!params) params = {};
    this.navCtrl.push(Page119Page);
  }goToPage120(params){
    if (!params) params = {};
    this.navCtrl.push(Page120Page);
  }goToPage121(params){
    if (!params) params = {};
    this.navCtrl.push(Page121Page);
  }goToPage122(params){
    if (!params) params = {};
    this.navCtrl.push(Page122Page);
  }goToPage123(params){
    if (!params) params = {};
    this.navCtrl.push(Page123Page);
  }goToPage124(params){
    if (!params) params = {};
    this.navCtrl.push(Page124Page);
  }goToPage125(params){
    if (!params) params = {};
    this.navCtrl.push(Page125Page);
  }goToPage126(params){
    if (!params) params = {};
    this.navCtrl.push(Page126Page);
  }goToPage127(params){
    if (!params) params = {};
    this.navCtrl.push(Page127Page);
  }goToPage128(params){
    if (!params) params = {};
    this.navCtrl.push(Page128Page);
  }goToPage129(params){
    if (!params) params = {};
    this.navCtrl.push(Page129Page);
  }goToPage130(params){
    if (!params) params = {};
    this.navCtrl.push(Page130Page);
  }goToPage131(params){
    if (!params) params = {};
    this.navCtrl.push(Page131Page);
  }goToPage132(params){
    if (!params) params = {};
    this.navCtrl.push(Page132Page);
  }goToPage133(params){
    if (!params) params = {};
    this.navCtrl.push(Page133Page);
  }goToPage134(params){
    if (!params) params = {};
    this.navCtrl.push(Page134Page);
  }goToPage136(params){
    if (!params) params = {};
    this.navCtrl.push(Page136Page);
  }goToPage137(params){
    if (!params) params = {};
    this.navCtrl.push(Page137Page);
  }goToPage138(params){
    if (!params) params = {};
    this.navCtrl.push(Page138Page);
  }goToPage140(params){
    if (!params) params = {};
    this.navCtrl.push(Page140Page);
  }goToPage139(params){
    if (!params) params = {};
    this.navCtrl.push(Page139Page);
  }goToPage160(params){
    if (!params) params = {};
    this.navCtrl.push(Page160Page);
  }goToPage161(params){
    if (!params) params = {};
    this.navCtrl.push(Page161Page);
  }goToPage162(params){
    if (!params) params = {};
    this.navCtrl.push(Page162Page);
  }goToPage163(params){
    if (!params) params = {};
    this.navCtrl.push(Page163Page);
  }goToPage164(params){
    if (!params) params = {};
    this.navCtrl.push(Page164Page);
  }goToPage165(params){
    if (!params) params = {};
    this.navCtrl.push(Page165Page);
  }
}
