import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page126',
  templateUrl: 'page126.html'
})
export class Page126Page {

  constructor(public navCtrl: NavController) {
  }
  
}
