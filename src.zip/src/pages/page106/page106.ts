import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page106',
  templateUrl: 'page106.html'
})
export class Page106Page {

  constructor(public navCtrl: NavController) {
  }
  
}
