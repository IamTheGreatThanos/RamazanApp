import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page52',
  templateUrl: 'page52.html'
})
export class Page52Page {

  constructor(public navCtrl: NavController) {
  }
  
}
