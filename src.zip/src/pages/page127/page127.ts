import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page127',
  templateUrl: 'page127.html'
})
export class Page127Page {

  constructor(public navCtrl: NavController) {
  }
  
}
