import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page131',
  templateUrl: 'page131.html'
})
export class Page131Page {

  constructor(public navCtrl: NavController) {
  }
  
}
