import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page162',
  templateUrl: 'page162.html'
})
export class Page162Page {

  constructor(public navCtrl: NavController) {
  }
  
}
