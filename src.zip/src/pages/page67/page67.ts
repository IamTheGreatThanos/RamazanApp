import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page67',
  templateUrl: 'page67.html'
})
export class Page67Page {

  constructor(public navCtrl: NavController) {
  }
  
}
