import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page115',
  templateUrl: 'page115.html'
})
export class Page115Page {

  constructor(public navCtrl: NavController) {
  }
  
}
