import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page42',
  templateUrl: 'page42.html'
})
export class Page42Page {

  constructor(public navCtrl: NavController) {
  }
  
}
