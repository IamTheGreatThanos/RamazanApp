import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page165',
  templateUrl: 'page165.html'
})
export class Page165Page {

  constructor(public navCtrl: NavController) {
  }
  
}
