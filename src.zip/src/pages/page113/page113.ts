import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page113',
  templateUrl: 'page113.html'
})
export class Page113Page {

  constructor(public navCtrl: NavController) {
  }
  
}
