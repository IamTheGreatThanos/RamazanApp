import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page17',
  templateUrl: 'page17.html'
})
export class Page17Page {

  constructor(public navCtrl: NavController) {
  }
  
}
