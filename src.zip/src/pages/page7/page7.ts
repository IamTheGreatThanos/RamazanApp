import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page7',
  templateUrl: 'page7.html'
})
export class Page7Page {

  constructor(public navCtrl: NavController) {
  }
  
}
