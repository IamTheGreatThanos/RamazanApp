import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page101',
  templateUrl: 'page101.html'
})
export class Page101Page {

  constructor(public navCtrl: NavController) {
  }
  
}
