import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page60',
  templateUrl: 'page60.html'
})
export class Page60Page {

  constructor(public navCtrl: NavController) {
  }
  
}
