import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page128',
  templateUrl: 'page128.html'
})
export class Page128Page {

  constructor(public navCtrl: NavController) {
  }
  
}
