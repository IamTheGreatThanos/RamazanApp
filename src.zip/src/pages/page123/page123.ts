import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page123',
  templateUrl: 'page123.html'
})
export class Page123Page {

  constructor(public navCtrl: NavController) {
  }
  
}
