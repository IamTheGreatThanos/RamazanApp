import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page57',
  templateUrl: 'page57.html'
})
export class Page57Page {

  constructor(public navCtrl: NavController) {
  }
  
}
