import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page164',
  templateUrl: 'page164.html'
})
export class Page164Page {

  constructor(public navCtrl: NavController) {
  }
  
}
