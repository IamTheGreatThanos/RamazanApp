import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page62',
  templateUrl: 'page62.html'
})
export class Page62Page {

  constructor(public navCtrl: NavController) {
  }
  
}
