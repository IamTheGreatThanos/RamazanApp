import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page156',
  templateUrl: 'page156.html'
})
export class Page156Page {

  constructor(public navCtrl: NavController) {
  }
  
}
