import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page53',
  templateUrl: 'page53.html'
})
export class Page53Page {

  constructor(public navCtrl: NavController) {
  }
  
}
