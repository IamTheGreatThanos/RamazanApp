import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page157',
  templateUrl: 'page157.html'
})
export class Page157Page {

  constructor(public navCtrl: NavController) {
  }
  
}
