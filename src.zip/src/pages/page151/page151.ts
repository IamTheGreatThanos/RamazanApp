import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page151',
  templateUrl: 'page151.html'
})
export class Page151Page {

  constructor(public navCtrl: NavController) {
  }
  
}
