import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page161',
  templateUrl: 'page161.html'
})
export class Page161Page {

  constructor(public navCtrl: NavController) {
  }
  
}
