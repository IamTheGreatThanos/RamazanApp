import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page50',
  templateUrl: 'page50.html'
})
export class Page50Page {

  constructor(public navCtrl: NavController) {
  }
  
}
