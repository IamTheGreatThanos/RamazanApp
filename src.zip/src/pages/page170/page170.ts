import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page170',
  templateUrl: 'page170.html'
})
export class Page170Page {

  constructor(public navCtrl: NavController) {
  }
  
}
