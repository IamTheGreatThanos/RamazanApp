import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page129',
  templateUrl: 'page129.html'
})
export class Page129Page {

  constructor(public navCtrl: NavController) {
  }
  
}
