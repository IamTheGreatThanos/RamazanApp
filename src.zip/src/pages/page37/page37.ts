import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page37',
  templateUrl: 'page37.html'
})
export class Page37Page {

  constructor(public navCtrl: NavController) {
  }
  
}
