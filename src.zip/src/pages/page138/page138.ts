import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page138',
  templateUrl: 'page138.html'
})
export class Page138Page {

  constructor(public navCtrl: NavController) {
  }
  
}
