import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page49',
  templateUrl: 'page49.html'
})
export class Page49Page {

  constructor(public navCtrl: NavController) {
  }
  
}
