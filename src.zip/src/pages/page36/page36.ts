import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page36',
  templateUrl: 'page36.html'
})
export class Page36Page {

  constructor(public navCtrl: NavController) {
  }
  
}
