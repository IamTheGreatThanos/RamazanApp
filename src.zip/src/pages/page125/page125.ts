import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page125',
  templateUrl: 'page125.html'
})
export class Page125Page {

  constructor(public navCtrl: NavController) {
  }
  
}
