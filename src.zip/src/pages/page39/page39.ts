import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page39',
  templateUrl: 'page39.html'
})
export class Page39Page {

  constructor(public navCtrl: NavController) {
  }
  
}
