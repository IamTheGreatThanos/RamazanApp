import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page56',
  templateUrl: 'page56.html'
})
export class Page56Page {

  constructor(public navCtrl: NavController) {
  }
  
}
