import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page104',
  templateUrl: 'page104.html'
})
export class Page104Page {

  constructor(public navCtrl: NavController) {
  }
  
}
