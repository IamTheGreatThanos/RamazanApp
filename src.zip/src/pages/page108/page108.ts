import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page108',
  templateUrl: 'page108.html'
})
export class Page108Page {

  constructor(public navCtrl: NavController) {
  }
  
}
