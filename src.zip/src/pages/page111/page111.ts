import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page111',
  templateUrl: 'page111.html'
})
export class Page111Page {

  constructor(public navCtrl: NavController) {
  }
  
}
