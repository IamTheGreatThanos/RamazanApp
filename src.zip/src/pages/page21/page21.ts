import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page21',
  templateUrl: 'page21.html'
})
export class Page21Page {

  constructor(public navCtrl: NavController) {
  }
  
}
