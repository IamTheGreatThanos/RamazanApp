import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page159',
  templateUrl: 'page159.html'
})
export class Page159Page {

  constructor(public navCtrl: NavController) {
  }
  
}
