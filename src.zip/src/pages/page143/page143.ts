import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page143',
  templateUrl: 'page143.html'
})
export class Page143Page {

  constructor(public navCtrl: NavController) {
  }
  
}
