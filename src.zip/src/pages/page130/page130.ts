import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page130',
  templateUrl: 'page130.html'
})
export class Page130Page {

  constructor(public navCtrl: NavController) {
  }
  
}
