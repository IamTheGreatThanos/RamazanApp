import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';
import { Page3Page } from '../page3/page3';
import { Page83Page } from '../page83/page83';
import { Page101Page } from '../page101/page101';
import { Page104Page } from '../page104/page104';
import { Page135Page } from '../page135/page135';
import { Page106Page } from '../page106/page106';
import { Page107Page } from '../page107/page107';
import { Page108Page } from '../page108/page108';
import { Page110Page } from '../page110/page110';
import { Page111Page } from '../page111/page111';
import { Page112Page } from '../page112/page112';
import { Page113Page } from '../page113/page113';
import { Page114Page } from '../page114/page114';
import { Page115Page } from '../page115/page115';
import { Page116Page } from '../page116/page116';
import { Page118Page } from '../page118/page118';
import { Page119Page } from '../page119/page119';
import { Page120Page } from '../page120/page120';
import { Page121Page } from '../page121/page121';
import { Page122Page } from '../page122/page122';
import { Page123Page } from '../page123/page123';
import { Page124Page } from '../page124/page124';
import { Page125Page } from '../page125/page125';
import { Page126Page } from '../page126/page126';
import { Page127Page } from '../page127/page127';
import { Page128Page } from '../page128/page128';
import { Page129Page } from '../page129/page129';
import { Page130Page } from '../page130/page130';
import { Page131Page } from '../page131/page131';
import { Page132Page } from '../page132/page132';
import { Page133Page } from '../page133/page133';
import { Page134Page } from '../page134/page134';
import { Page136Page } from '../page136/page136';
import { Page137Page } from '../page137/page137';
import { Page138Page } from '../page138/page138';
import { Page140Page } from '../page140/page140';
import { Page139Page } from '../page139/page139';
import { Page160Page } from '../page160/page160';
import { Page161Page } from '../page161/page161';
import { Page162Page } from '../page162/page162';
import { Page163Page } from '../page163/page163';
import { Page164Page } from '../page164/page164';
import { Page165Page } from '../page165/page165';
import { Page14Page } from '../page14/page14';
import { Page29Page } from '../page29/page29';
import { Page30Page } from '../page30/page30';
import { Page31Page } from '../page31/page31';
import { Page32Page } from '../page32/page32';
import { Page33Page } from '../page33/page33';
import { Page34Page } from '../page34/page34';
import { Page35Page } from '../page35/page35';
import { Page36Page } from '../page36/page36';
import { Page37Page } from '../page37/page37';
import { Page39Page } from '../page39/page39';
import { Page38Page } from '../page38/page38';
import { Page40Page } from '../page40/page40';
import { Page41Page } from '../page41/page41';
import { Page42Page } from '../page42/page42';
import { Page43Page } from '../page43/page43';
import { Page44Page } from '../page44/page44';
import { Page10Page } from '../page10/page10';
import { Page45Page } from '../page45/page45';
import { Page46Page } from '../page46/page46';
import { Page59Page } from '../page59/page59';
import { Page65Page } from '../page65/page65';
import { Page69Page } from '../page69/page69';
import { Page68Page } from '../page68/page68';
import { Page70Page } from '../page70/page70';
import { Page71Page } from '../page71/page71';
import { Page64Page } from '../page64/page64';
import { Page60Page } from '../page60/page60';
import { Page61Page } from '../page61/page61';
import { Page62Page } from '../page62/page62';
import { Page63Page } from '../page63/page63';
import { Page100Page } from '../page100/page100';
import { Page23Page } from '../page23/page23';
import { Page66Page } from '../page66/page66';
import { Page67Page } from '../page67/page67';
import { Page103Page } from '../page103/page103';
import { Page141Page } from '../page141/page141';
import { Page142Page } from '../page142/page142';
import { Page12Page } from '../page12/page12';
import { Page143Page } from '../page143/page143';
import { Page145Page } from '../page145/page145';
import { Page146Page } from '../page146/page146';
import { Page147Page } from '../page147/page147';
import { Page148Page } from '../page148/page148';
import { Page149Page } from '../page149/page149';
import { Page150Page } from '../page150/page150';
import { Page151Page } from '../page151/page151';
import { Page152Page } from '../page152/page152';
import { Page153Page } from '../page153/page153';
import { Page154Page } from '../page154/page154';
import { Page155Page } from '../page155/page155';
import { Page156Page } from '../page156/page156';
import { Page157Page } from '../page157/page157';
import { Page158Page } from '../page158/page158';
import { Page159Page } from '../page159/page159';
import { Page109Page } from '../page109/page109';
import { Page144Page } from '../page144/page144';
import { Page170Page } from '../page170/page170';
import { Page166Page } from '../page166/page166';
import { Page167Page } from '../page167/page167';
import { Page168Page } from '../page168/page168';
import { Page169Page } from '../page169/page169';
import { Page11Page } from '../page11/page11';
import { Page25Page } from '../page25/page25';
import { Page21Page } from '../page21/page21';
import { Page26Page } from '../page26/page26';
import { Page27Page } from '../page27/page27';
import { Page28Page } from '../page28/page28';
import { Page56Page } from '../page56/page56';
import { Page57Page } from '../page57/page57';
import { Page58Page } from '../page58/page58';
import { Page22Page } from '../page22/page22';
import { Page47Page } from '../page47/page47';
import { Page16Page } from '../page16/page16';
import { Page15Page } from '../page15/page15';
import { Page48Page } from '../page48/page48';
import { Page102Page } from '../page102/page102';
import { Page2Page } from '../page2/page2';
import { Page5Page } from '../page5/page5';
import { Page6Page } from '../page6/page6';
import { Page18Page } from '../page18/page18';
import { Page7Page } from '../page7/page7';
import { Page99Page } from '../page99/page99';
import { Page24Page } from '../page24/page24';
import { Page50Page } from '../page50/page50';
import { Page51Page } from '../page51/page51';
import { Page52Page } from '../page52/page52';
import { Page53Page } from '../page53/page53';
import { Page54Page } from '../page54/page54';
import { Page55Page } from '../page55/page55';
import { Page105Page } from '../page105/page105';

@Component({
  selector: 'page-page1',
  templateUrl: 'page1.html'
})
export class Page1Page {

  constructor(public navCtrl: NavController) {
  }
  goToPage3(params){
    if (!params) params = {};
    this.navCtrl.push(Page3Page);
  }goToPage83(params){
    if (!params) params = {};
    this.navCtrl.push(Page83Page);
  }goToPage101(params){
    if (!params) params = {};
    this.navCtrl.push(Page101Page);
  }goToPage104(params){
    if (!params) params = {};
    this.navCtrl.push(Page104Page);
  }goToPage135(params){
    if (!params) params = {};
    this.navCtrl.push(Page135Page);
  }goToPage106(params){
    if (!params) params = {};
    this.navCtrl.push(Page106Page);
  }goToPage107(params){
    if (!params) params = {};
    this.navCtrl.push(Page107Page);
  }goToPage108(params){
    if (!params) params = {};
    this.navCtrl.push(Page108Page);
  }goToPage110(params){
    if (!params) params = {};
    this.navCtrl.push(Page110Page);
  }goToPage111(params){
    if (!params) params = {};
    this.navCtrl.push(Page111Page);
  }goToPage112(params){
    if (!params) params = {};
    this.navCtrl.push(Page112Page);
  }goToPage113(params){
    if (!params) params = {};
    this.navCtrl.push(Page113Page);
  }goToPage114(params){
    if (!params) params = {};
    this.navCtrl.push(Page114Page);
  }goToPage115(params){
    if (!params) params = {};
    this.navCtrl.push(Page115Page);
  }goToPage116(params){
    if (!params) params = {};
    this.navCtrl.push(Page116Page);
  }goToPage118(params){
    if (!params) params = {};
    this.navCtrl.push(Page118Page);
  }goToPage119(params){
    if (!params) params = {};
    this.navCtrl.push(Page119Page);
  }goToPage120(params){
    if (!params) params = {};
    this.navCtrl.push(Page120Page);
  }goToPage121(params){
    if (!params) params = {};
    this.navCtrl.push(Page121Page);
  }goToPage122(params){
    if (!params) params = {};
    this.navCtrl.push(Page122Page);
  }goToPage123(params){
    if (!params) params = {};
    this.navCtrl.push(Page123Page);
  }goToPage124(params){
    if (!params) params = {};
    this.navCtrl.push(Page124Page);
  }goToPage125(params){
    if (!params) params = {};
    this.navCtrl.push(Page125Page);
  }goToPage126(params){
    if (!params) params = {};
    this.navCtrl.push(Page126Page);
  }goToPage127(params){
    if (!params) params = {};
    this.navCtrl.push(Page127Page);
  }goToPage128(params){
    if (!params) params = {};
    this.navCtrl.push(Page128Page);
  }goToPage129(params){
    if (!params) params = {};
    this.navCtrl.push(Page129Page);
  }goToPage130(params){
    if (!params) params = {};
    this.navCtrl.push(Page130Page);
  }goToPage131(params){
    if (!params) params = {};
    this.navCtrl.push(Page131Page);
  }goToPage132(params){
    if (!params) params = {};
    this.navCtrl.push(Page132Page);
  }goToPage133(params){
    if (!params) params = {};
    this.navCtrl.push(Page133Page);
  }goToPage134(params){
    if (!params) params = {};
    this.navCtrl.push(Page134Page);
  }goToPage136(params){
    if (!params) params = {};
    this.navCtrl.push(Page136Page);
  }goToPage137(params){
    if (!params) params = {};
    this.navCtrl.push(Page137Page);
  }goToPage138(params){
    if (!params) params = {};
    this.navCtrl.push(Page138Page);
  }goToPage140(params){
    if (!params) params = {};
    this.navCtrl.push(Page140Page);
  }goToPage139(params){
    if (!params) params = {};
    this.navCtrl.push(Page139Page);
  }goToPage160(params){
    if (!params) params = {};
    this.navCtrl.push(Page160Page);
  }goToPage161(params){
    if (!params) params = {};
    this.navCtrl.push(Page161Page);
  }goToPage162(params){
    if (!params) params = {};
    this.navCtrl.push(Page162Page);
  }goToPage163(params){
    if (!params) params = {};
    this.navCtrl.push(Page163Page);
  }goToPage164(params){
    if (!params) params = {};
    this.navCtrl.push(Page164Page);
  }goToPage165(params){
    if (!params) params = {};
    this.navCtrl.push(Page165Page);
  }goToPage14(params){
    if (!params) params = {};
    this.navCtrl.push(Page14Page);
  }goToPage29(params){
    if (!params) params = {};
    this.navCtrl.push(Page29Page);
  }goToPage30(params){
    if (!params) params = {};
    this.navCtrl.push(Page30Page);
  }goToPage31(params){
    if (!params) params = {};
    this.navCtrl.push(Page31Page);
  }goToPage32(params){
    if (!params) params = {};
    this.navCtrl.push(Page32Page);
  }goToPage33(params){
    if (!params) params = {};
    this.navCtrl.push(Page33Page);
  }goToPage34(params){
    if (!params) params = {};
    this.navCtrl.push(Page34Page);
  }goToPage35(params){
    if (!params) params = {};
    this.navCtrl.push(Page35Page);
  }goToPage36(params){
    if (!params) params = {};
    this.navCtrl.push(Page36Page);
  }goToPage37(params){
    if (!params) params = {};
    this.navCtrl.push(Page37Page);
  }goToPage39(params){
    if (!params) params = {};
    this.navCtrl.push(Page39Page);
  }goToPage38(params){
    if (!params) params = {};
    this.navCtrl.push(Page38Page);
  }goToPage40(params){
    if (!params) params = {};
    this.navCtrl.push(Page40Page);
  }goToPage41(params){
    if (!params) params = {};
    this.navCtrl.push(Page41Page);
  }goToPage42(params){
    if (!params) params = {};
    this.navCtrl.push(Page42Page);
  }goToPage43(params){
    if (!params) params = {};
    this.navCtrl.push(Page43Page);
  }goToPage44(params){
    if (!params) params = {};
    this.navCtrl.push(Page44Page);
  }goToPage10(params){
    if (!params) params = {};
    this.navCtrl.push(Page10Page);
  }goToPage45(params){
    if (!params) params = {};
    this.navCtrl.push(Page45Page);
  }goToPage46(params){
    if (!params) params = {};
    this.navCtrl.push(Page46Page);
  }goToPage59(params){
    if (!params) params = {};
    this.navCtrl.push(Page59Page);
  }goToPage65(params){
    if (!params) params = {};
    this.navCtrl.push(Page65Page);
  }goToPage69(params){
    if (!params) params = {};
    this.navCtrl.push(Page69Page);
  }goToPage68(params){
    if (!params) params = {};
    this.navCtrl.push(Page68Page);
  }goToPage70(params){
    if (!params) params = {};
    this.navCtrl.push(Page70Page);
  }goToPage71(params){
    if (!params) params = {};
    this.navCtrl.push(Page71Page);
  }goToPage64(params){
    if (!params) params = {};
    this.navCtrl.push(Page64Page);
  }goToPage60(params){
    if (!params) params = {};
    this.navCtrl.push(Page60Page);
  }goToPage61(params){
    if (!params) params = {};
    this.navCtrl.push(Page61Page);
  }goToPage62(params){
    if (!params) params = {};
    this.navCtrl.push(Page62Page);
  }goToPage63(params){
    if (!params) params = {};
    this.navCtrl.push(Page63Page);
  }goToPage100(params){
    if (!params) params = {};
    this.navCtrl.push(Page100Page);
  }goToPage23(params){
    if (!params) params = {};
    this.navCtrl.push(Page23Page);
  }goToPage66(params){
    if (!params) params = {};
    this.navCtrl.push(Page66Page);
  }goToPage67(params){
    if (!params) params = {};
    this.navCtrl.push(Page67Page);
  }goToPage103(params){
    if (!params) params = {};
    this.navCtrl.push(Page103Page);
  }goToPage141(params){
    if (!params) params = {};
    this.navCtrl.push(Page141Page);
  }goToPage142(params){
    if (!params) params = {};
    this.navCtrl.push(Page142Page);
  }goToPage12(params){
    if (!params) params = {};
    this.navCtrl.push(Page12Page);
  }goToPage143(params){
    if (!params) params = {};
    this.navCtrl.push(Page143Page);
  }goToPage145(params){
    if (!params) params = {};
    this.navCtrl.push(Page145Page);
  }goToPage146(params){
    if (!params) params = {};
    this.navCtrl.push(Page146Page);
  }goToPage147(params){
    if (!params) params = {};
    this.navCtrl.push(Page147Page);
  }goToPage148(params){
    if (!params) params = {};
    this.navCtrl.push(Page148Page);
  }goToPage149(params){
    if (!params) params = {};
    this.navCtrl.push(Page149Page);
  }goToPage150(params){
    if (!params) params = {};
    this.navCtrl.push(Page150Page);
  }goToPage151(params){
    if (!params) params = {};
    this.navCtrl.push(Page151Page);
  }goToPage152(params){
    if (!params) params = {};
    this.navCtrl.push(Page152Page);
  }goToPage153(params){
    if (!params) params = {};
    this.navCtrl.push(Page153Page);
  }goToPage154(params){
    if (!params) params = {};
    this.navCtrl.push(Page154Page);
  }goToPage155(params){
    if (!params) params = {};
    this.navCtrl.push(Page155Page);
  }goToPage156(params){
    if (!params) params = {};
    this.navCtrl.push(Page156Page);
  }goToPage157(params){
    if (!params) params = {};
    this.navCtrl.push(Page157Page);
  }goToPage158(params){
    if (!params) params = {};
    this.navCtrl.push(Page158Page);
  }goToPage159(params){
    if (!params) params = {};
    this.navCtrl.push(Page159Page);
  }goToPage109(params){
    if (!params) params = {};
    this.navCtrl.push(Page109Page);
  }goToPage144(params){
    if (!params) params = {};
    this.navCtrl.push(Page144Page);
  }goToPage170(params){
    if (!params) params = {};
    this.navCtrl.push(Page170Page);
  }goToPage166(params){
    if (!params) params = {};
    this.navCtrl.push(Page166Page);
  }goToPage167(params){
    if (!params) params = {};
    this.navCtrl.push(Page167Page);
  }goToPage168(params){
    if (!params) params = {};
    this.navCtrl.push(Page168Page);
  }goToPage169(params){
    if (!params) params = {};
    this.navCtrl.push(Page169Page);
  }goToPage11(params){
    if (!params) params = {};
    this.navCtrl.push(Page11Page);
  }goToPage25(params){
    if (!params) params = {};
    this.navCtrl.push(Page25Page);
  }goToPage21(params){
    if (!params) params = {};
    this.navCtrl.push(Page21Page);
  }goToPage26(params){
    if (!params) params = {};
    this.navCtrl.push(Page26Page);
  }goToPage27(params){
    if (!params) params = {};
    this.navCtrl.push(Page27Page);
  }goToPage28(params){
    if (!params) params = {};
    this.navCtrl.push(Page28Page);
  }goToPage56(params){
    if (!params) params = {};
    this.navCtrl.push(Page56Page);
  }goToPage57(params){
    if (!params) params = {};
    this.navCtrl.push(Page57Page);
  }goToPage58(params){
    if (!params) params = {};
    this.navCtrl.push(Page58Page);
  }goToPage22(params){
    if (!params) params = {};
    this.navCtrl.push(Page22Page);
  }goToPage47(params){
    if (!params) params = {};
    this.navCtrl.push(Page47Page);
  }goToPage16(params){
    if (!params) params = {};
    this.navCtrl.push(Page16Page);
  }goToPage15(params){
    if (!params) params = {};
    this.navCtrl.push(Page15Page);
  }goToPage48(params){
    if (!params) params = {};
    this.navCtrl.push(Page48Page);
  }goToPage102(params){
    if (!params) params = {};
    this.navCtrl.push(Page102Page);
  }goToPage2(params){
    if (!params) params = {};
    this.navCtrl.push(Page2Page);
  }goToPage5(params){
    if (!params) params = {};
    this.navCtrl.push(Page5Page);
  }goToPage6(params){
    if (!params) params = {};
    this.navCtrl.push(Page6Page);
  }goToPage18(params){
    if (!params) params = {};
    this.navCtrl.push(Page18Page);
  }goToPage7(params){
    if (!params) params = {};
    this.navCtrl.push(Page7Page);
  }goToPage99(params){
    if (!params) params = {};
    this.navCtrl.push(Page99Page);
  }goToPage24(params){
    if (!params) params = {};
    this.navCtrl.push(Page24Page);
  }goToPage50(params){
    if (!params) params = {};
    this.navCtrl.push(Page50Page);
  }goToPage51(params){
    if (!params) params = {};
    this.navCtrl.push(Page51Page);
  }goToPage52(params){
    if (!params) params = {};
    this.navCtrl.push(Page52Page);
  }goToPage53(params){
    if (!params) params = {};
    this.navCtrl.push(Page53Page);
  }goToPage54(params){
    if (!params) params = {};
    this.navCtrl.push(Page54Page);
  }goToPage55(params){
    if (!params) params = {};
    this.navCtrl.push(Page55Page);
  }goToPage105(params){
    if (!params) params = {};
    this.navCtrl.push(Page105Page);
  }
}
