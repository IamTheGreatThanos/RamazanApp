import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page40',
  templateUrl: 'page40.html'
})
export class Page40Page {

  constructor(public navCtrl: NavController) {
  }
  
}
