import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page38',
  templateUrl: 'page38.html'
})
export class Page38Page {

  constructor(public navCtrl: NavController) {
  }
  
}
