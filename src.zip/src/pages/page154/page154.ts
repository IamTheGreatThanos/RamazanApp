import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page154',
  templateUrl: 'page154.html'
})
export class Page154Page {

  constructor(public navCtrl: NavController) {
  }
  
}
