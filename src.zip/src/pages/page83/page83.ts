import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page83',
  templateUrl: 'page83.html'
})
export class Page83Page {

  constructor(public navCtrl: NavController) {
  }
  
}
