import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page51',
  templateUrl: 'page51.html'
})
export class Page51Page {

  constructor(public navCtrl: NavController) {
  }
  
}
