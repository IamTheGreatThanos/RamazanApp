import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page139',
  templateUrl: 'page139.html'
})
export class Page139Page {

  constructor(public navCtrl: NavController) {
  }
  
}
