import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page34',
  templateUrl: 'page34.html'
})
export class Page34Page {

  constructor(public navCtrl: NavController) {
  }
  
}
