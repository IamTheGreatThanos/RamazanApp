import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page137',
  templateUrl: 'page137.html'
})
export class Page137Page {

  constructor(public navCtrl: NavController) {
  }
  
}
