import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page105',
  templateUrl: 'page105.html'
})
export class Page105Page {

  constructor(public navCtrl: NavController) {
  }
  
}
