import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page43',
  templateUrl: 'page43.html'
})
export class Page43Page {

  constructor(public navCtrl: NavController) {
  }
  
}
