import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page150',
  templateUrl: 'page150.html'
})
export class Page150Page {

  constructor(public navCtrl: NavController) {
  }
  
}
