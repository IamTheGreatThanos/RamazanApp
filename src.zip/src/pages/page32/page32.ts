import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page32',
  templateUrl: 'page32.html'
})
export class Page32Page {

  constructor(public navCtrl: NavController) {
  }
  
}
