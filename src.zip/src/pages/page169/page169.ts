import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page169',
  templateUrl: 'page169.html'
})
export class Page169Page {

  constructor(public navCtrl: NavController) {
  }
  
}
