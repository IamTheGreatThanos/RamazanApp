import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page18',
  templateUrl: 'page18.html'
})
export class Page18Page {

  constructor(public navCtrl: NavController) {
  }
  
}
