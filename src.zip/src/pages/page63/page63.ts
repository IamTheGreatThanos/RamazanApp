import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page63',
  templateUrl: 'page63.html'
})
export class Page63Page {

  constructor(public navCtrl: NavController) {
  }
  
}
