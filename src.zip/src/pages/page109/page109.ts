import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page109',
  templateUrl: 'page109.html'
})
export class Page109Page {

  constructor(public navCtrl: NavController) {
  }
  
}
