import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page35',
  templateUrl: 'page35.html'
})
export class Page35Page {

  constructor(public navCtrl: NavController) {
  }
  
}
