import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page121',
  templateUrl: 'page121.html'
})
export class Page121Page {

  constructor(public navCtrl: NavController) {
  }
  
}
