import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page158',
  templateUrl: 'page158.html'
})
export class Page158Page {

  constructor(public navCtrl: NavController) {
  }
  
}
