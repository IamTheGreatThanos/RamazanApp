# Settings

The Settings page shows a settings form that is configurable, along with features for nested options where the user navigates to sub options while still using the same Settings page code.
