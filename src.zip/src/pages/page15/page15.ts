import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page15',
  templateUrl: 'page15.html'
})
export class Page15Page {

  constructor(public navCtrl: NavController) {
  }
  
}
