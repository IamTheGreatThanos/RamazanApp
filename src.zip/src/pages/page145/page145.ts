import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page145',
  templateUrl: 'page145.html'
})
export class Page145Page {

  constructor(public navCtrl: NavController) {
  }
  
}
