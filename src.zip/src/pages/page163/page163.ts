import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page163',
  templateUrl: 'page163.html'
})
export class Page163Page {

  constructor(public navCtrl: NavController) {
  }
  
}
