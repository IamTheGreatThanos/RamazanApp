import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page160',
  templateUrl: 'page160.html'
})
export class Page160Page {

  constructor(public navCtrl: NavController) {
  }
  
}
