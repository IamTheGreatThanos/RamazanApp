import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page122',
  templateUrl: 'page122.html'
})
export class Page122Page {

  constructor(public navCtrl: NavController) {
  }
  
}
