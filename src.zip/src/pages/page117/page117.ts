import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page117',
  templateUrl: 'page117.html'
})
export class Page117Page {

  constructor(public navCtrl: NavController) {
  }
  
}
