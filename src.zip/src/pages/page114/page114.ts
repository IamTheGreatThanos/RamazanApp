import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page114',
  templateUrl: 'page114.html'
})
export class Page114Page {

  constructor(public navCtrl: NavController) {
  }
  
}
