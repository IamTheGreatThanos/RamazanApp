import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page71',
  templateUrl: 'page71.html'
})
export class Page71Page {

  constructor(public navCtrl: NavController) {
  }
  
}
