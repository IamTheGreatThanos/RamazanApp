import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page16',
  templateUrl: 'page16.html'
})
export class Page16Page {

  constructor(public navCtrl: NavController) {
  }
  
}
