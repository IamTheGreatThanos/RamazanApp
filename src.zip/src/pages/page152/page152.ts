import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page152',
  templateUrl: 'page152.html'
})
export class Page152Page {

  constructor(public navCtrl: NavController) {
  }
  
}
