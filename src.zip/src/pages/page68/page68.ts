import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page68',
  templateUrl: 'page68.html'
})
export class Page68Page {

  constructor(public navCtrl: NavController) {
  }
  
}
