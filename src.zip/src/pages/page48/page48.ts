import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page48',
  templateUrl: 'page48.html'
})
export class Page48Page {

  constructor(public navCtrl: NavController) {
  }
  
}
