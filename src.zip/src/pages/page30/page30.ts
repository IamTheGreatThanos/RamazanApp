import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page30',
  templateUrl: 'page30.html'
})
export class Page30Page {

  constructor(public navCtrl: NavController) {
  }
  
}
