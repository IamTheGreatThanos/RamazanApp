import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page168',
  templateUrl: 'page168.html'
})
export class Page168Page {

  constructor(public navCtrl: NavController) {
  }
  
}
