import { Component } from '@angular/core';
import { NavController } from 'ionic-angular';

@Component({
  selector: 'page-page124',
  templateUrl: 'page124.html'
})
export class Page124Page {

  constructor(public navCtrl: NavController) {
  }
  
}
